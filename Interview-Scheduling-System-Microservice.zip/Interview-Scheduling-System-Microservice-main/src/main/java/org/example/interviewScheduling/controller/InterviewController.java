package org.example.interviewScheduling.controller;

import org.example.interviewScheduling.dto.FeedbackRequest;
import org.example.interviewScheduling.dto.ScheduleInterviewRequest;
import org.example.interviewScheduling.entity.Candidate;
import org.example.interviewScheduling.entity.Feedback;
import org.example.interviewScheduling.entity.Interview;
import org.example.interviewScheduling.entity.Interviewer;
import org.example.interviewScheduling.service.InterviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("interviews")
public class InterviewController {

    @Autowired
    private InterviewService service;

    @PostMapping
    public ResponseEntity<Interview> scheduleInterview(@RequestBody ScheduleInterviewRequest reqest) {
        Interview interview = service.scheduleInterview(reqest);
        return ResponseEntity.status(201).body(interview);
    }

    @PostMapping("/candidate")
    public ResponseEntity<Candidate> createCandidate(@RequestBody Candidate candidate) throws Exception {

        Candidate c = service.crateCandidate(candidate);
        return ResponseEntity.status(201).body(c);
    }

    @PostMapping("/interviewer")
    public ResponseEntity<Interviewer> createCandidate(@RequestBody Interviewer interviewer){
        Interviewer i = service.createInterviewer(interviewer);
        return ResponseEntity.status(201).body(i);
    }

    @PostMapping("interview/{id}/feedback")
    public ResponseEntity<Feedback> submitFeedback(@PathVariable("id") UUID id, @RequestBody FeedbackRequest request) {
        Feedback feedback = service.submitFeedback(id, request);
        return ResponseEntity.status(201).body(feedback);
    }

    @GetMapping("/find")
    public ResponseEntity<Page<Interview>> searchInterviews(@RequestParam(required = false) String candidate,
                                                            @RequestParam(required = false) String interviewer,
                                                            @RequestParam(defaultValue = "0") int page,
                                                            @RequestParam(defaultValue = "5") int size) {
        Pageable pageable = PageRequest.of(page, size);

        Page<Interview> result =
                service.searchInterviews(candidate, interviewer, pageable);

        return ResponseEntity.ok(result);
    }


}
