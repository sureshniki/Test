package org.example.interviewScheduling.repository;

import org.example.interviewScheduling.entity.Interviewer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface InterviewerRepository extends JpaRepository<Interviewer, UUID> {
}
