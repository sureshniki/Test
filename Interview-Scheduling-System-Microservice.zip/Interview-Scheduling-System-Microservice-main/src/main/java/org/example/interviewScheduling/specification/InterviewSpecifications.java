package org.example.interviewScheduling.specification;

import jakarta.persistence.criteria.Join;
import org.example.interviewScheduling.entity.Candidate;
import org.example.interviewScheduling.entity.Interview;
import org.example.interviewScheduling.entity.Interviewer;
import org.springframework.data.jpa.domain.Specification;

public class InterviewSpecifications {

    // SPEC : start, prepare, expand, compare.

    public static Specification<Interview> candidateNameContains(String name) {

        // root - main table
        // criteriaBuilder
        return (root, query, criteriaBuilder) -> {
            if (name == null || name.isBlank()) {
                return criteriaBuilder.conjunction(); // means no filter critiea needed.no condition
            }

            Join<Interview, Candidate> candidate = root.join("candidate");

            return criteriaBuilder.like(
                    criteriaBuilder.lower(candidate.get("name")),
                    "%" + name.toLowerCase() + "%");
        };
    }

    public static Specification<Interview> interviewerNameContains(String name) {
        return (root, query, criteriaBuilder) -> {
            if (name == null || name.isBlank()) {
                return criteriaBuilder.conjunction();
            }

            Join<Interview, Interviewer> interviewer = root.join("interviewers");

            return criteriaBuilder.like(criteriaBuilder.lower(interviewer.get("name")), "%" +
                    name.toLowerCase() + "%");
        };
    }


}
