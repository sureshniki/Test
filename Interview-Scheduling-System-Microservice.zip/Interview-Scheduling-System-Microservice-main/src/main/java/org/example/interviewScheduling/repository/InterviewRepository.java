package org.example.interviewScheduling.repository;

import org.example.interviewScheduling.entity.Interview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.UUID;

public interface InterviewRepository extends JpaRepository<Interview, UUID>,
        JpaSpecificationExecutor<Interview> {
}
