package org.example.interviewScheduling.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.interviewScheduling.enums.InterviewStatus;

import java.time.OffsetDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Interview {
    @Id
    @GeneratedValue
    @Column(nullable = false)
    private UUID id;

    @ManyToOne(optional = false)
    private Candidate candidate;

    @ManyToMany
    @JoinTable(
            name = "interview_interviewers",
            joinColumns = @JoinColumn(name = "interview_id"),
            inverseJoinColumns = @JoinColumn(name = "interviewer_id")
    )
    private Set<Interviewer> interviewers = new HashSet<>();

    @Column(nullable = false)
    private OffsetDateTime scheduledAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private InterviewStatus status;

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public Candidate getCandidate() {
		return candidate;
	}

	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}

	public Set<Interviewer> getInterviewers() {
		return interviewers;
	}

	public void setInterviewers(Set<Interviewer> interviewers) {
		this.interviewers = interviewers;
	}

	public OffsetDateTime getScheduledAt() {
		return scheduledAt;
	}

	public void setScheduledAt(OffsetDateTime scheduledAt) {
		this.scheduledAt = scheduledAt;
	}

	public InterviewStatus getStatus() {
		return status;
	}

	public void setStatus(InterviewStatus status) {
		this.status = status;
	}

}
