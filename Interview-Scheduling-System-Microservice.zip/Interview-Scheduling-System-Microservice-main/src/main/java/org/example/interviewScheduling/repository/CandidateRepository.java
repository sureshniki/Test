package org.example.interviewScheduling.repository;

import org.example.interviewScheduling.entity.Candidate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface CandidateRepository extends JpaRepository<Candidate, UUID>{
}
