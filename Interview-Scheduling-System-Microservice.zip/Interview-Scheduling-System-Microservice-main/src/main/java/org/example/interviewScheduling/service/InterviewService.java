package org.example.interviewScheduling.service;

import jakarta.transaction.Transactional;
import org.example.interviewScheduling.dto.FeedbackRequest;
import org.example.interviewScheduling.dto.ScheduleInterviewRequest;
import org.example.interviewScheduling.entity.Candidate;
import org.example.interviewScheduling.entity.Feedback;
import org.example.interviewScheduling.entity.Interview;
import org.example.interviewScheduling.entity.Interviewer;
import org.example.interviewScheduling.enums.InterviewStatus;
import org.example.interviewScheduling.exception.NotFoundException;
import org.example.interviewScheduling.repository.CandidateRepository;
import org.example.interviewScheduling.repository.FeedbackRepository;
import org.example.interviewScheduling.repository.InterviewRepository;
import org.example.interviewScheduling.repository.InterviewerRepository;
import org.example.interviewScheduling.specification.InterviewSpecifications;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class InterviewService {

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private InterviewerRepository interviewerRepository;

    @Autowired
    private InterviewRepository interviewRepository;

    @Autowired
    private FeedbackRepository feedbackRepository;


    public Candidate crateCandidate(Candidate candidate) throws Exception {
        String[] ccheck = candidate.getEmail().split("@");
        String address = ccheck[1].toString();
        if (!address.equals("gmail.com")) {
            throw new Exception("invalid email address");
        }
        return candidateRepository.save(candidate);
    }

    public Interviewer createInterviewer(Interviewer interviewer){
        return interviewerRepository.save(interviewer);
    }

    // scheduleInterview
    @Transactional
    public Interview scheduleInterview(ScheduleInterviewRequest request) {

        Candidate candidate = candidateRepository.findById(request.candidateId())
                .orElseThrow(() -> new RuntimeException("candidate not found"));

        List<Interviewer> interviewers = interviewerRepository.findAllById(request.interviewerIds());
        Interview interview = new Interview();
        interview.setCandidate(candidate);
        interview.getInterviewers().addAll(interviewers);
        interview.setScheduledAt(request.scheduledAt());
        interview.setStatus(InterviewStatus.SCHEDULED);

        return interviewRepository.save(interview);
    }

    @Transactional
    public Feedback submitFeedback(UUID interviewId, FeedbackRequest request)  {

        Interview interview = interviewRepository.findById(interviewId)
                .orElseThrow(() -> new NotFoundException("Interview not found"));

        Interviewer interviewer = interviewerRepository.findById(request.interviewerId())
                .orElseThrow(() -> new NotFoundException("Interviewer not found"));

        boolean interviewerAssigned = interview.getInterviewers().stream()
                .noneMatch(i -> i.getId().equals(interviewer.getId()));

        if (interviewerAssigned) {
            throw new IllegalArgumentException("Interviewer is not assigned to this interview");
        }

        Feedback feedback = new Feedback();
        feedback.setInterview(interview);
        feedback.setInterviewer(interviewer);
        feedback.setComments(request.comments());
        feedback.setRating(request.rating());

        return feedbackRepository.save(feedback);
    }

    // search using specification
    public Page<Interview> searchInterviews(String candidate, String interviewer, Pageable pageable){

    Specification<Interview> spec = Specification
                .where(InterviewSpecifications.candidateNameContains(candidate))
                .and(InterviewSpecifications.interviewerNameContains(interviewer));

        return interviewRepository.findAll(spec, pageable);
    }


}
