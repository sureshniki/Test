package org.example.interviewScheduling.enums;

public enum InterviewStatus {

    SCHEDULED,
    COMPLETED,
    CANCELLED
}
