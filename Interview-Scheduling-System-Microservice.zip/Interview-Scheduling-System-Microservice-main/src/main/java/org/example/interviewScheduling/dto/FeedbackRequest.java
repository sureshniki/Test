package org.example.interviewScheduling.dto;

import java.util.UUID;

public record FeedbackRequest(UUID interviewerId,
                              String comments,
                              int rating) {
}
