package org.example.interviewScheduling.dto;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

public record ScheduleInterviewRequest(UUID candidateId, List<UUID> interviewerIds,
                                       OffsetDateTime scheduledAt) {
}
